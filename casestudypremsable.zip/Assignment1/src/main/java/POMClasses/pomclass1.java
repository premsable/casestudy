package POMClasses;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import baseclass.baseclass;

public class pomclass1 extends baseclass{
	public pomclass1(){
		PageFactory.initElements(driver, this);
		
	}
	
	@FindBy(xpath="//input[@autofocus=\"autofocus\"]")
	WebElement searchbox;
	 

	@FindBy(xpath="(//div[@class=\"DgCNMb\"])[1]")
	WebElement WankhadestadiumClick;
	
	@FindBy(xpath="(//span[text()=\"Wankhede Stadium\"])[1]")
	WebElement Veriyfystadiumtext;
	
	@FindBy(xpath="//div[@class=\"fontDisplayLarge\"]")
	WebElement verifypoint;
	
	@FindBy(xpath="(//button[@class=\"DkEaL\"])[1]")
	WebElement verifyreviews;
	
	@FindBy(xpath="(//div[@class='Io6YTe fontBodyMedium'])[2] ")
	WebElement verifyLink;
	
	@FindBy(xpath="(//div[@class='Io6YTe fontBodyMedium'])[1]")
	WebElement verifyAddress;
	
	@FindBy(xpath="//div[text()=\"022 2279 5500\"]")
	WebElement verifyPhoneNum;
	
	public void searchbox() 
	{
		 searchbox.sendKeys("Wankhede Stedium");	
	}
    public void WankhadestadiumClick() {
    	WankhadestadiumClick.click();
    }
    public void Veriyfystadiumtext() {
    	String expected ="Stadium ";
    	Veriyfystadiumtext.getText();
    	String actualresult=Veriyfystadiumtext.getText();
    	if(actualresult.equals(expected)) {
    		System.out.println(" Text Present �Stadium� in the left frame");
    	}else {
    		System.out.println("Text not Present �Stadium� in the left frame  text is avaiable in left flame:="+" "+actualresult);
    	}
    	
    }
    	
    public void verifypoint() {
    	verifypoint.getText();
    System.out.println(" the point:- " + " "+verifypoint.getText());
    
    }
    public void verifyreviews() {
    	System.out.println(" the review :- " + " "+verifyreviews.getText());
    }
    public void verifyLink() {
    	System.out.println(" the link:-"+" "+verifyLink.getText());
         }
   public void verifyAddress() {
	  
	   System.out.println(" the adress:-"+" "+verifyAddress.getText());
   }
   public void verifyPhoneNum() {
	   System.out.println(" the phonenumber:- "+"  "+ verifyPhoneNum.getText());
	  
	   
   }
         public void gettitle() {
	     driver.getTitle();
   }
   

}
