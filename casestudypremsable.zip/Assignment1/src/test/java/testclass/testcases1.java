package testclass;

import java.io.IOException;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import POMClasses.pomclass1;
import baseclass.baseclass;

public class testcases1 extends  baseclass {
	pomclass1 pm;// gobalily declear

	public testcases1() {
		super();
	}
	@BeforeMethod
	public  void setup() throws InterruptedException, IOException {
		initialization();
		pm=new pomclass1();
		pm.searchbox();
		Thread.sleep(3000);
		pm.WankhadestadiumClick();
		Thread.sleep(3000);
	    System.out.println(" Verify the Title:- "+ driver.getTitle());
	    Thread.sleep(2000);
		getScreenShot();
	}
	@Test
	public void verifyallcondition() throws InterruptedException, IOException {
		pm.Veriyfystadiumtext();
		Thread.sleep(2000);
		Thread.sleep(2000);
		pm.verifypoint();
		Thread.sleep(2000);
		pm.verifyreviews();
		Thread.sleep(2000);
		pm.verifyLink();
		Thread.sleep(2000);
		pm.verifyAddress();
		Thread.sleep(2000);
		pm.verifyPhoneNum();
		Thread.sleep(2000);
		getScreenShot();
	        
		
	}

	
	@AfterMethod
	public void TearDown() {
		driver.quit();
	}
   
}

