package POMClasses;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import baseclass.baseclass;

public class pomclass1 extends baseclass{
	
	public pomclass1() {
		PageFactory.initElements(driver, this);
		
	}
	@FindBy(xpath="//input[@placeholder='Search']")
	WebElement searchbox;
	
	@FindBy(xpath="//h1[contains(text(),'1,000+ search results for �The Godfather�')]")
	WebElement moviesearchresult;
	
	@FindBy(xpath="//p[normalize-space()='Directed by Francis Ford Coppola, Albert S. Ruddy']")
	WebElement clickmovieyear1972;
	
	@FindBy(xpath="//span[@class=\"header-movie-genres\"]")
	WebElement VerifygenreCRIME;
	
	@FindBy(xpath="//span[6]")
	WebElement MPAArating ;
	
	@FindBy(xpath="//a[@title='Cast & Crew']")
	WebElement clickCastCrew; 
	
	@FindBy(xpath="//dt[@class='name artist-name']//a[contains(text(),'Francis Ford Coppola')]")
	WebElement VerifyFrancisForCoppola;
;
	
	@FindBy(xpath="//div[normalize-space()='Michael Corleone']")
	WebElement MichaeLCorleone;
	
	
	public void  searchbox() {
		searchbox.sendKeys("The Godfather" );
	}
	public void clickmovieyear1972() {
		clickmovieyear1972.click();
		System.out.println("current page tittle:-"+" "+driver.getTitle());
	}
	public void verifymoviesearchresult() {
		System.out.println("103 search results for the godfather ");
		
	}
	public void verifycrime() {
	
	 String actual="Genres - Crime";
	 String expected="Genres - Crime";
	 if(actual.equalsIgnoreCase(expected)) {
		 System.out.println( " The crime is present:-"+"  "+VerifygenreCRIME.getText());
		 
	 }
	 else 
	 {
		 System.out.println("Genres - Crime Is Not Present");
	 }
		
	}
	
	public void verifyMPPArating() {
		 MPAArating.getText();
		 String actual= MPAArating.getText();
		 String expected=" MPAA Rating - A";
		 
		 if(actual.equals(expected)) {
			 System.out.println(" Caorrect MPAA Rating - A");
		 }else 
		 {
			 System.out.println(" Diffrent Rating   MPAA Rating - R ");
		 }
	}
	public void clickCastCrew() {
		clickCastCrew.click();
	}
	public void  VerifyFrancisForCoppola() {
		
		String expected="Francis Ford Coppola";
		String actual=VerifyFrancisForCoppola.getText();
		
		if(actual.equalsIgnoreCase(expected)) {
		
			System.out.println(VerifyFrancisForCoppola.getText());	
		}else {
			System.out.println(" Francis Ford Coppola Not Present ");
		}
	}
	
	public void verifyMichaeLCorleone() {
		String expected="Michael Corleone";
		String actual=MichaeLCorleone.getText();
		
		if(actual.equalsIgnoreCase(expected)) {
		
			System.out.println(MichaeLCorleone.getText());	
			
		}else {
			System.out.println(" Michael Corleone Not Present ");
		}
		
		
		
		
		
		
		
		
		
	}
	
}
