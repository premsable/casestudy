package baseclass;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.io.FileHandler;

public class baseclass {
	public static WebDriver driver;
	public static Properties prop;

	public baseclass() {
		FileInputStream ip;
		try {
			prop=new Properties();
			ip = new FileInputStream("F:\\ecplipse\\Assignment2\\src\\main\\java\\DataDrivenfile\\config.file");
			prop.load(ip);
	
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
			
		} catch(IOException e) {
	    	e.printStackTrace();
		
		}
	}
		public static void initialization() {
			
			String browsername = prop.getProperty("browser");
			System.setProperty("webdriver.gecko.driver", "C:\\Selenium\\firefoxdriver\\geckodriver.exe");

			  driver = new FirefoxDriver(); 
			  
			  driver.manage().window().maximize();  
			  
			  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			  
			  driver.get(prop.getProperty("url"));
		}
		public  static void getScreenShot() throws IOException
		   {
			TakesScreenshot ts= (TakesScreenshot)driver;
			File src= ts.getScreenshotAs(OutputType.FILE);
			File trg= new File(".\\screenshort\\allmovie.png");
			FileHandler.copy(src, trg);

}

}
