package Testcases;

import java.io.IOException;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import POMClasses.pomclass1;
import baseclass.baseclass;

public class testcases1  extends baseclass{
	pomclass1 pm ;
	public testcases1() {
		super();
	}
	@BeforeMethod
	public void browserinvoke() throws InterruptedException {
		initialization();
		Thread.sleep(2000);
	}
	@Test
	public void verifyallcondition() throws InterruptedException, IOException {
		pm=new pomclass1();
		pm.searchbox();
		Thread.sleep(3000);
		pm.verifymoviesearchresult();
		Thread.sleep(3000);
		pm.clickmovieyear1972();
		Thread.sleep(3000);
		pm.verifycrime();
		Thread.sleep(2000);
		pm.verifyMPPArating();
		Thread.sleep(3000);
		getScreenShot();
		Thread.sleep(2000);
		pm.clickCastCrew();
		Thread.sleep(2000);
		pm.VerifyFrancisForCoppola();
		Thread.sleep(2000);
		pm.verifyMichaeLCorleone();
		
	}
		
	@AfterMethod
	public void teardown() {
		driver.quit();
	}
	

}
